import os
import json
import boto3
import logging
import urllib.parse

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# clients
glue = boto3.client('glue')
sns  = boto3.client('sns')

# env vars
GLUE_JOB_NAME    = os.environ['GLUE_JOB_NAME']        # e.g. "supply-chain-iceberg-job"
GLUE_DATABASE    = os.environ['GLUE_DATABASE_NAME']   # e.g. "supply_chain_db"
SNS_TOPIC_ARN    = os.environ['SNS_TOPIC_ARN']        # e.g. "arn:aws:sns:…:dehtopic"

# only process these subfolders
VALID_PREFIXES = (
    'raw/inventory/',
    'raw/orders/',
    'raw/shipments/',
    'raw/suppliers/',
    'raw/warehouses/'
)

def lambda_handler(event, context):
    try:
        detail = event['detail']
        bucket = detail['bucket']['name']
        key    = urllib.parse.unquote_plus(detail['object']['key'])
        logger.info(f"S3 event: bucket={bucket} key={key}")

        # ignore non-CSV or unexpected paths
        if not key.lower().endswith('.csv') or not any(key.startswith(p) for p in VALID_PREFIXES):
            logger.info("Ignored file (not in valid raw folder or not CSV).")
            return {'statusCode': 200}

        # start the Glue ETL job
        resp = glue.start_job_run(
            JobName=GLUE_JOB_NAME,
            Arguments={
                '--bucket': bucket,
                '--key': key,
                '--glue_database_name': GLUE_DATABASE
            }
        )
        run_id = resp['JobRunId']
        logger.info(f"Started Glue job {GLUE_JOB_NAME} (run-id={run_id}) for s3://{bucket}/{key}")

        # notify “started” with a clean, multi-line message
        subject = f"Glue ETL Job Started: {GLUE_JOB_NAME}"
        message = f"""
Glue ETL Job Triggered Successfully!

Job Name   : {GLUE_JOB_NAME}
Run ID     : {run_id}
S3 Path    : s3://{bucket}/{key}
Database   : {GLUE_DATABASE}

This is an automated notification from your event-driven pipeline.
"""
        sns.publish(
            TopicArn=SNS_TOPIC_ARN,
            Subject=subject,
            Message=message.strip()
        )

        return {'statusCode': 200}

    except Exception as e:
        logger.error("Error in Lambda handler", exc_info=True)

        # notify “failed to start” with details
        subject = f"Glue ETL Job Submission Failed: {GLUE_JOB_NAME}"
        message = f"""
Glue ETL Job Submission Failed!

Job Name   : {GLUE_JOB_NAME}
Error      : {str(e)}
S3 Path    : s3://{bucket}/{key if 'bucket' in locals() and 'key' in locals() else 'unknown'}
Database   : {GLUE_DATABASE}

Please investigate the error in CloudWatch Logs.
"""
        sns.publish(
            TopicArn=SNS_TOPIC_ARN,
            Subject=subject,
            Message=message.strip()
        )

        # re-raise so Lambda shows a failure in CloudWatch
        raise
