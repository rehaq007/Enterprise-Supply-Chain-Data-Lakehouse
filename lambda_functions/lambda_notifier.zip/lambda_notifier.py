import os
import json
import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# clients
sns  = boto3.client('sns')
glue = boto3.client('glue')

# env vars
SNS_TOPIC_ARN    = os.environ['SNS_TOPIC_ARN']      # arn:aws:sns:…:dehtopic

def lambda_handler(event, context):
    detail = event.get('detail', {})

    # 1) Grab basic identifiers
    job_name   = detail.get('jobName', 'Unknown')
    job_run_id = detail.get('jobRunId', 'Unknown')

    # 2) Fetch the full job‐run info, which includes Arguments and the true state
    try:
        jr_resp = glue.get_job_run(JobName=job_name, RunId=job_run_id)
        jr      = jr_resp['JobRun']
        state   = jr.get('JobRunState', 'Unknown')
        args    = jr.get('Arguments', {})
    except Exception as e:
        logger.warning(f"Could not fetch job run details: {e}")
        # fallback to whatever the event might have
        state = detail.get('jobRunState') or detail.get('state') or 'Unknown'
        args  = detail.get('arguments', {})

    # 3) Extract the S3 info (defaults to Unknown if missing)
    bucket = args.get('--bucket', 'Unknown')
    key    = args.get('--key',    'Unknown')

    # 4) Build a clean subject & message
    subject = f"Glue Job Result: {job_name} → {state}"
    message = f"""
Glue Job Notification

Job Name           : {job_name}
Job Run ID         : {job_run_id}
Status             : {state}
S3 File Processed  : s3://{bucket}/{key}

This is an automated message from your EventBridge → Lambda → SNS pipeline.
""".strip()

    logger.info("Publishing friendly SNS notification")
    sns.publish(
        TopicArn= SNS_TOPIC_ARN,
        Subject=  subject,
        Message=  message
    )

    return {
        'statusCode': 200,
        'body': json.dumps('Glue job notification sent')
    }

